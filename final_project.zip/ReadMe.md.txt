PACKAGES TO BE INSTALLED:

1.[keras]
2.[numpy]
3.[pandas]
4.[matplotlib]
5.[scikit-learn]
6.[cv2]

Dataset :
  
you can find the plant seedling data set in below:  
              
 [ https://www.kaggle.com/c/plant-seedlings-classification]